=================================================================================================================================================
IMPORTANT INFORMATION
=================================================================================================================================================
By using one of my projects you're accepting the "AS IS" policy.
Author (unknownproject) is an oldskool grayhat hacker and a reverse engineer. !!!Not a modder!!!
Author is not responsible for your own lack of knowledge/hardware damages or anything else that happens with your system(s).
Each project includes various txt files. They're available as individual downloads just because I want. 
If you don't want to read them - don't even try to ask help.
Author is making these things as his own hobby and spending as much time as possible so your requests and complaining just make no sense for him.
You are not allowed to distribute/dissassemble my projects without linking to original resources and/or mentioning me.
[Nukers are lamers].
=================================================================================================================================================
Contacts:
Email - nknwn.project@gmail.com
Steam - http://steamcommunity.com/profiles/76561198017988277
YouTube - https://www.youtube.com/channel/UCCjgivnEXTz7vLE4n894Wsg
=================================================================================================================================================
Donate:
https://qiwi.me/support_unknownproject
https://money.yandex.ru/bill/pay/WHt3qQC6Hcs.191016

If you wish to use alternative ways - just contact me.
=================================================================================================================================================